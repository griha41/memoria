﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Lib.Web.Mvc.JQuery.JqGrid
{
    /// <summary>
    /// jqGrid options
    /// </summary>
    public class JqGridOptions
    {
        #region Fields
        private List<JqGridColumnModel> _columnsModel;
        private List<string> _columnsNames;
        #endregion

        #region Properties
        /// <summary>
        /// Gets the grid identifier which will be used for table (id='{0}'), pager div (id='{0}Pager') and in JavaScript.
        /// </summary>
        public string Id { get; private set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after every inserted row.
        /// </summary>
        public string AfterInsertRow { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after the edited cell is edited.
        /// </summary>
        public string AfterEditCell { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after calling the method restoreCell or the user press ESC leaving the changes.
        /// </summary>
        public string AfterRestoreCell { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after the cell has been successfully saved.
        /// </summary>
        public string AfterSaveCell { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after the cell and other data is posted to the server.
        /// </summary>
        public string AfterSubmitCell { get; set; }

        /// <summary>
        /// Gets or sets the value indicating if the grid width will be recalculated automatically to the width of the parent element.
        /// </summary>
        public bool AutoWidth { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised before requesting any data.
        /// </summary>
        public string BeforeRequest { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised when the user click on the row, but before selecting it.
        /// </summary>
        public string BeforeSelectRow { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised before editing the cell.
        /// </summary>
        public string BeforeEditCell { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised before validation of values if any.
        /// </summary>
        public string BeforeSaveCell { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised before submit the cell content to the server.
        /// </summary>
        public string BeforeSubmitCell { get; set; }

        /// <summary>
        /// Gets or sets the caption for the grid.
        /// </summary>
        public string Caption { get; set; }

        /// <summary>
        /// Gets or sets the value indicating if cell editing is enabled
        /// </summary>
        public bool CellEditingEnabled { get; set; }

        /// <summary>
        /// Gets or sets the cell editing submit mode
        /// </summary>
        public JqGridCellEditingSubmitModes CellEditingSubmitMode { get; set; }

        /// <summary>
        /// Gets or set the URL for cell editing submit
        /// </summary>
        public string CellEditingUrl { get; set; }

        /// <summary>
        /// Gets the list of columns parameters descriptions.
        /// </summary>
        public List<JqGridColumnModel> ColumnsModels { get { return _columnsModel; } }

        /// <summary>
        /// Gets the list of columns names.
        /// </summary>
        public List<string> ColumnsNames { get { return _columnsNames; } }

        /// <summary>
        /// Gets or sets the list of columns indexes for remaping (default null).
        /// </summary>
        public List<int> ColumnsRemaping { get; set;  }

        /// <summary>
        /// Gets or sets the string of data which will be used when DataType is set to JqGridDataTypes.XmlString or JqGridDataTypes.JsonString (default null).
        /// </summary>
        public string DataString { get; set; }

        /// <summary>
        /// Gets or sets the type of information to expect to represent data in the grid (default JqGridDataTypes.Xml).
        /// </summary>
        public JqGridDataTypes DataType { get; set; }

        /// <summary>
        /// Gets or sets the value which defines if dynamic scrolling is enabled.
        /// </summary>
        public JqGridDynamicScrollingModes DynamicScrollingMode { get; set; }

        /// <summary>
        /// Gets or sets the timeout (in miliseconds) if DynamicScrollingMode is set to JqGridDynamicScrollingModes.HoldVisibleRows
        /// </summary>
        public int DynamicScrollingTimeout { get; set; }

        /// <summary>
        /// Gets or sets the url for inline and form editing.
        /// </summary>
        public string EditingUrl { get; set; }

        /// <summary>
        /// Gets or sets the value which defines whether the tree is expanded and/or collapsed when user clicks on the text of the expanded column, not only on the image.
        /// </summary>
        public bool ExpandColumnClick { get; set; }

        /// <summary>
        /// Gets or sets the name of column which should be used to expand the tree grid.
        /// </summary>
        public string ExpandColumn { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised when there is a server error while saving cell.
        /// </summary>
        public string ErrorCell { get; set; }

        /// <summary>
        /// Gets or sets the function for event which allows formatting the cell content before editing.
        /// </summary>
        public string FormatCell { get; set; }

        /// <summary>
        /// Gets or sets the value indicating if the footer table (with one row) will be placed below the grid records and above the pager. The number of columns equal of these from ColumnsModels.
        /// </summary>
        public bool FooterEnabled { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after all the data is loaded into the grid and all other processes are complete.
        /// </summary>
        public string GridComplete { get; set; }

        /// <summary>
        /// Gets or sets the value indicating if the grouping is enabled.
        /// </summary>
        public bool GroupingEnabled { get; set; }

        /// <summary>
        /// Gets or sets the grouping view options.
        /// </summary>
        public JqGridGroupingView GroupingView { get; set; }

        /// <summary>
        /// Gets or sets the height of the grid in pixels (default 'auto').
        /// </summary>
        public int? Height { get; set; }

        /// <summary>
        /// Gets or sets the value which defines whether the grid is initialy hidden (no data loaded, only caption layer is shown).
        /// Takes effect only if the Caption property is not empty string and HiddenEnabled is set to true.
        /// </summary>
        public bool Hidden { get; set; }

        /// <summary>
        /// Gets or sets the value which defines whether the show/hide grid button is enabled.
        /// Takes effect only if the Caption property is not empty string.
        /// </summary>
        public bool HiddenEnabled { get; set; }

        /// <summary>
        /// Gets or sets the JSON reader for the grid.
        /// </summary>
        public JqGridJsonReader JsonReader { get; set; }

        /// <summary>
        /// Gets or sets the function for pre-callback to modify the XMLHttpRequest object before it is sent.
        /// </summary>
        public string LoadBeforeSend { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised immediately after every server request.
        /// </summary>
        public string LoadComplete { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after the request fails.
        /// </summary>
        public string LoadError { get; set; }

        /// <summary>
        /// Gets or sets the type of request to make (default JqGridMethodTypes.Get).
        /// </summary>
        public JqGridMethodTypes MethodType { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised when user clicks on particular cell in the grid.
        /// </summary>
        public string OnCellSelect { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised immediately after row was double clicked.
        /// </summary>
        public string OnDoubleClickRow { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after clicking to hide or show grid.
        /// </summary>
        public string OnHeaderClick { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised before populating the data after page index/size change.
        /// </summary>
        public string OnPaging { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised immediately after row was right clicked.
        /// </summary>
        public string OnRightClickRow { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised when MultipleSelect option is true and user clicks on the header checkbox.
        /// </summary>
        public string OnSelectAll { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after the cell is selected for editing.
        /// </summary>
        public string OnSelectCell { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised immediately after row was clicked.
        /// </summary>
        public string OnSelectRow { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised immediately after sortable column was clicked and before sorting the data.
        /// </summary>
        public string OnSortCol { get; set; }

        /// <summary>
        /// Gets or sets if grid should use a pager bar to navigate through the records (default: false).
        /// </summary>
        public bool Pager { get; set; }

        /// <summary>
        /// Gets or sets customized names for jqGrid request parameters.
        /// </summary>
        public JqGridParametersNames ParametersNames { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised when user starts resizing a column.
        /// </summary>
        public string ResizeStart { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised after the column is resized.
        /// </summary>
        public string ResizeStop { get; set; }

        /// <summary>
        /// Gets or sets an array to construct a select box element in the pager in which user can change the number of the visible rows.
        /// </summary>
        public List<int> RowsList { get; set; }

        /// <summary>
        /// Gets or sets how many records should be displayed in the grid (default 20).
        /// </summary>
        public int RowsNumber { get; set; }

        /// <summary>
        /// Gets or sets the width of vertical scrollbar
        /// </summary>
        public int ScrollOffset { get; set; }

        /// <summary>
        /// Gets or sets the function for event which can serialize the data passed to the ajax request when the cell is being saved.
        /// </summary>
        public string SerializeCellData { get; set; }

        /// <summary>
        /// Gets or sets the function for event which can serialize the data passed to the ajax request.
        /// </summary>
        public string SerializeGridData { get; set; }

        /// <summary>
        /// Gets or sets the function for event which can serialize the data passed to the subgrid ajax request.
        /// </summary>
        public string SerializeSubGridData { get; set; }

        /// <summary>
        /// Gets or sets the initial sorting column index, when  using data returned from server (default: String.Empty)
        /// </summary>
        public string SortingName { get; set; }

        /// <summary>
        /// Gets or sets the initial sorting order, when  using data returned from server (default JqGridSortingOrders.Asc)
        /// </summary>
        public JqGridSortingOrders SortingOrder { get; set; }

        /// <summary>
        /// Gets or sets the value which defines if subgrid is enabled.
        /// </summary>
        public bool SubgridEnabled { get; set; }

        /// <summary>
        /// Gets or sets the subgrid model.
        /// </summary>
        public JqGridSubgridModel SubgridModel { get; set; }

        /// <summary>
        /// Gets or sets the url for subgrid data requests.
        /// </summary>
        public string SubgridUrl { get; set; }

        /// <summary>
        /// Gets or sets the width of subgrid expand/colapse column.
        /// </summary>
        public int SubgridColumnWidth { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised just before expanding the subgrid.
        /// </summary>
        public string SubGridBeforeExpand { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised when the user clicks on the plus icon of the grid.
        /// </summary>
        public string SubGridRowExpanded { get; set; }

        /// <summary>
        /// Gets or sets the function for event which is raised when the user clicks on the minus icon of the grid.
        /// </summary>
        public string SubGridRowColapsed { get; set; }

        /// <summary>
        /// Gets or sets the value which defines if TreeGrid is enabled.
        /// </summary>
        public bool TreeGridEnabled { get; set; }

        /// <summary>
        /// Gets or sets the model for TreeGrid.
        /// </summary>
        public JqGridTreeGridModels TreeGridModel { get; set; }

        /// <summary>
        /// Gets or sets the url for data requests (default null)
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// Gets or sets the value indicating if the values from user data should be placed on footer.
        /// </summary>
        public bool UserDataOnFooter { get; set; }

        /// <summary>
        /// Gets or sets if grid should display the beginning and ending record number out of the total number of records in the query (default: false)
        /// </summary>
        public bool ViewRecords { get; set; }

        /// <summary>
        /// Gets or sets the width of the grid in pixels (default 'auto').
        /// </summary>
		public int? Width { get; set; }
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the JqGridOptions class.
        /// </summary>
        /// <param name="id">Identifier, which will be used for table (id='{0}'), pager div (id='{0}Pager'), filter grid div (id='{0}Search') and in JavaScript.</param>
        public JqGridOptions(string id)
        {
            Id = id;
            _columnsModel = new List<JqGridColumnModel>();
            _columnsNames = new List<string>();

            AfterInsertRow = null;
            AfterEditCell = null;
            AfterRestoreCell = null;
            AfterSaveCell = null;
            AfterSubmitCell = null;
            AutoWidth = false;
            BeforeRequest = null;
            BeforeSelectRow = null;
            BeforeEditCell = null;
            BeforeSaveCell = null;
            BeforeSubmitCell = null;
            Caption = String.Empty;
            CellEditingEnabled = false;
            CellEditingSubmitMode = JqGridCellEditingSubmitModes.Remote;
            CellEditingUrl = null;
            ColumnsRemaping = null;
            DataString = null;
            DataType = JqGridDataTypes.Xml;
            DynamicScrollingMode = JqGridDynamicScrollingModes.Disabled;
            DynamicScrollingTimeout = 200;
            EditingUrl = null;
            ExpandColumn = null;
            ExpandColumnClick = true;
            ErrorCell = null;
            FormatCell = null;
            FooterEnabled = false;
            GridComplete = null;
            GroupingEnabled = false;
            GroupingView = null;
            Height = null;
            Hidden = false;
            HiddenEnabled = true;
            JsonReader = JqGridResponse.JsonReader;
            LoadBeforeSend = null;
            LoadComplete = null;
            LoadError = null;
            MethodType = JqGridMethodTypes.Get;
            OnCellSelect = null;
            OnDoubleClickRow = null;
            OnHeaderClick = null;
            OnPaging = null;
            OnRightClickRow = null;
            OnSelectAll = null;
            OnSelectCell = null;
            OnSelectRow = null;
            OnSortCol = null;
            Pager = false;
            ParametersNames = JqGridRequest.ParameterNames;
            ResizeStart = null;
            ResizeStop = null;
            RowsList = null;
            RowsNumber = 20;
            ScrollOffset = 18;
            SerializeCellData = null;
            SerializeGridData = null;
            SerializeSubGridData = null;
            SortingName = String.Empty;
            SortingOrder = JqGridSortingOrders.Asc;
            SubgridColumnWidth = 20;
            SubgridEnabled = false;
            SubgridModel = null;
            SubgridUrl = String.Empty;
            SubGridBeforeExpand = null;
            SubGridRowColapsed = null;
            SubGridRowExpanded = null;
            TreeGridEnabled = false;
            TreeGridModel = JqGridTreeGridModels.Nested;
            Url = null;
            UserDataOnFooter = false;
            ViewRecords = false;
            Width = null;
        }
        #endregion

        #region Methods
        internal bool UseDataString()
        {
            return (this.DataType == JqGridDataTypes.JsonString || this.DataType == JqGridDataTypes.XmlString);
        }
        #endregion
    }
}
