﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lib.Web.Mvc.JQuery.JqGrid
{
    /// <summary>
    /// Base class for classes which represents options for jqGrid Navigator controls
    /// </summary>
    public abstract class JqGridNavigatorControlOptions
    {
    }
}
