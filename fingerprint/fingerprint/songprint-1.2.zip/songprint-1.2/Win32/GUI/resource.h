//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SongSigDemo.rc
//

/*  
 *
 *  Copyright (C) 2000  eTantrum, Inc.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
 */

#define IDD_ABOUTBOX                    100
#define IDD_WAITDIALOG                  101
#define IDR_MAINFRAME                   150
#define IDR_SSDTYPE                     151
#define IDD_DIRCHOOSER                  152
#define IDB_DRIVEIMAGES                 153
#define IDC_DIRECTORYTREE               1000
#define IDC_RECURSESUBDIRS              1001
#define IDC_WAITMSG                     1002
#define ID_ADDSONGS                     57610
#define ID_ADDDIRECTORY                 57611

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         57613
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
