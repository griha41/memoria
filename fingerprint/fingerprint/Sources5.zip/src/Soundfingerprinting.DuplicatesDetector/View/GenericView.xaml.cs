﻿// Sound Fingerprinting framework
// git://github.com/AddictedCS/soundfingerprinting.git
// Code license: CPOL v.1.02
// ciumac.sergiu@gmail.com
namespace Soundfingerprinting.DuplicatesDetector.View
{
    /// <summary>
    ///   Interaction logic for GenericReportView.xaml
    /// </summary>
    public partial class GenericView
    {
        public GenericView()
        {
            InitializeComponent();
        }
    }
}